class ModelNotFoundException(ValueError):
    pass

class OptionNotFoundException(ValueError):
    pass
